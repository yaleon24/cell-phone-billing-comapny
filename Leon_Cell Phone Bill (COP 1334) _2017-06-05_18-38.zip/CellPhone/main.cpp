#include <iostream>
#include <iomanip>
/*

Write a program that calculates and prints the bill for a cell phone company.  The company offers two types of service: regular and premium.  Its rates vary, depending on the type of service.
The rates are computed as follows:

Regular service: $10.00 plus 50 minutes are free.  Charges for over 50 minutes are $.20 per minute.

Premium service: $25.00 plus:

a. For calls made from 6:00 a.m. to 6:00 p.m., the first 75 minutes are free; charges for over 75 minutes are $0.10 per minute.

b. For calls made from 6:00 p.m. to 6:00 a.m., the first 100 minutes are free; charges for over 100 minutes are $0.05 per minute.

Your program should prompt the user to enter an account number, a service code (type char), and the number of minutes the service was used.
A service code of R or r means regular service; a service code of P or p means premium service.  Treat any other character as an error.
Your program should output the account number, type of service, number of minutes the telephone service was used, and the amount due from the user.

For the premium service, the customer may be using the service during the day and the night.
Therefore, to calculate the bill, you must ask the user to input the number of minutes the service was used during the day and the number of minutes the service was used during the night.
*/
using namespace std;
const double regservice=10.00;
const double regpermin=0.20;
const double preservice=25.00;
const double preperminday=0.10;
const double preperminnight=0.05;
const double regfreemin=50;
const double dayprefreemin=75;
const double nightprefreemin=100;
int main()
{
    double regmin=0,daymin=0,nightmin=0,totaldue=0;
    int pretotalmin;
    double accountnum;
    char service;
    cout << "Enter an account number:" << endl;
    cin>>accountnum;
    if(accountnum>99999||accountnum<100000)
    {
        cout << "Enter R or r for regular service.  Enter P or p for premium service." << endl;
        cin>>service;
        if(service=='r'||service=='R')
        {
            cout << "Enter the number of minutes used." << endl;
            //for regular accounts
            cin>>regmin;
            if(regmin>regfreemin)
            {
                totaldue=regservice+((regmin-regfreemin)*regpermin);
            }
            else
            {
                totaldue=regservice;
            }
            cout << "Account number " <<accountnum<< " with regular service.  Total minutes: " <<regmin<< " Total Bill $" << fixed << setprecision(2) <<totaldue  << endl;
        }
        else if (service=='p'||service=='P')
        {
            cout << "Enter minutes of calls made between 6:00 a.m. to 6:00 p.m." << endl;
            cin>>daymin;
            if(daymin>dayprefreemin)
            {
                totaldue=preservice+((daymin-dayprefreemin)*preperminday);
            }
            else
            {
                totaldue=preservice;
            }
            cout << "Enter minutes of calls made between 6:00 p.m. to 6:00 a.m." << endl;
            //for premium accounts
            cin>>nightmin;
            if(nightmin>nightprefreemin)
            {
                totaldue+=((nightmin-nightprefreemin)*preperminnight);

            }
              pretotalmin=daymin+nightmin;
            cout << "Account number " <<accountnum<< " with premium service.  Total minutes: " <<pretotalmin<< " Total Bill $" << fixed << setprecision(2) <<totaldue  << endl;
        };
    }
    else
    {
        cout << "Invalid entry." << endl;
    }
    return 0;
}
